package com.cg.payroll.main;
import java.sql.SQLException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;

public class MainClass {

	public static void main(String[] args) throws SQLException, AssociateDetailsNotFoundException, PayrollServicesDownException {

		ApplicationContext applicationContext= new ClassPathXmlApplicationContext("projectbeans.xml");
		PayrollServices payrollServices=(PayrollServices) applicationContext.getBean("services");
		int associateId=payrollServices.acceptAssociateDetails("samykya", "thanuku", "sam.com", "ece", "analyst", "Bcpo1234", 12344, 900, 10, 10, 1234667, "XYZ", "GJJ767");
		int associateId1=payrollServices.acceptAssociateDetails("karunya", "thanuku", "binnu.com", "ece", "analyst", "Bcpo1234", 12344, 900, 10, 10, 123667, "XYZ", "GJJ767");
		int associateId2=payrollServices.acceptAssociateDetails("Manjula", "Rani", "mom.com", "mom", "analyst", "B1234", 145344, 900, 10, 10, 123456789, "XYZ", "GJJ767");

		//payrollServices.delete(associate);
		//payrollServices.updateAssociateDetails(1, "manjula", "thanuku", "mom", "fhgdf", "hfkd90", "sam.com", 12345, 200000, 100, 200, 98765, "icici", "ndfn89");
		//	payrollServices.updateAssociateDetails(new Associate(1234569, "Manjula", "Rani", "housewife", "mom", "djskm", "mom.com", 12345, new BankDetails(12345, "ICICI", "nfjdgn")));
		
		/*payrollServices.updateAssociateDetails(new Associate(1, 123456, "Manjula", "Rani", "Home", "Mom", "dhfd", "mom.com", new Salary(50000, 2000, 1000, 1000, 1000, 500, 200, 200, 500, 2000, 250000)));
		System.out.println("updated successfully");	*/
		
		/*System.out.println(payrollServices.getAllAssociateDetails());
		System.out.println("retrieved successfully");*/
		
		System.out.println(payrollServices.calculateNetSalary(associateId2));
		//payrollServices.deleteAssociate(1);
		//System.out.println("deleted successfully");
		
		
		//System.out.println(payrollServices.getAssociateDetails(1));
		//System.out.println(payrollServices.getAssociateDetails(2));
		//System.out.println("retrieved successfully");
	}
}


















/*		PayrollServices payrollServices = new PayrollServicesImpl();
		try{
			PayrollUtility.getDBConnection();
		//int associateID= payrollServices.acceptAssociateDetails("mani", "reddy", "mani.com", "eee", "analyst", "FHU788", 12000, 5000, 200, 100, 123456, "gyfg", "GUJH76");
			//System.out.println(associateID);
		//	int associateID= payrollServices.acceptAssociateDetails("anu", "reddy", "mani.com", "eee", "analyst", "FHU788", 12000, 5000, 200, 100, 123456, "gyfg", "GUJH76");
			//System.out.println(associateID);

			System.out.println(payrollServices.calculateNetSalary(101));
			//System.out.println(payrollServices.delete());


		}
		catch(PayrollServicesDownException e){
			e.printStackTrace();

		}*/

