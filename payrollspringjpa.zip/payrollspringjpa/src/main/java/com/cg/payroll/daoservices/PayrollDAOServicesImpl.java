package com.cg.payroll.daoservices;


import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.payroll.beans.Associate;


@Component("daoServices")

public class PayrollDAOServicesImpl implements PayrollDAOServices {
	@Autowired(required=true)
	private EntityManagerFactory entityManagerFactory;
	public int insertAssociate(Associate associate) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(associate);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return associate.getAssociateID();
	}

	public boolean updateAssociate(Associate associate) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(associate);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}

	public Associate getAssociate(int associateId) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		Associate associate=entityManager.find(Associate.class, associateId);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return associate;
	}

	public List<Associate> getAssociates() {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		Query query=entityManager.createQuery("FROM Associate",Associate.class);
		return query.getResultList();
	}

	public boolean deleteAssociate(int associateId) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		Associate associate=entityManager.getReference(Associate.class, associateId);
		entityManager.remove(associate);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
/*	private SessionFactory sessionFactory;

	public int insertAssociate(Associate associate) {
		sessionFactory.openSession().save(associate);
		sessionFactory.openSession().flush();
		return 0;
	}

	public boolean updateAssociate(Associate associate) {
		Session session = sessionFactory.openSession();
	      Transaction tx = null;
	      
	      try {
	         tx = session.beginTransaction();
	         Associate associate1=(Associate) session.get(Associate.class, associate);
			 session.update(associate1); 
	         tx.commit();
	      } catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
		//Associate associate1 =(Associate) sessionFactory.openSession().get(Associate.class, associate1 );
		return true;
	}

	public Associate getAssociate(int associateId) {
		Associate associate=(Associate) sessionFactory.openSession().get(Associate.class, associateId);
		return associate; 
	}
	public List<Associate> getAssociates() {
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("FROM Associate");
		return query.list();
	}
	public boolean deleteAssociate(int associateId) {
		
		Session session=sessionFactory.openSession();
		Associate associate=getAssociate(associateId);
		session.delete(associate);
		session.flush();
		return true;
	}*/
		
		/*Session session = sessionFactory.openSession();
		Associate associate=(Associate) session.get(Associate.class, associateId);
		session.delete(associate);
		return true;*/
		/*Session session = sessionFactory.openSession();
	    Transaction tx = null;
	    
	    try {
	       tx = session.beginTransaction();
	       Associate associate=(Associate) session.get(Associate.class, associateId);
			session.delete(associate);
	       tx.commit();
	    } catch (HibernateException e) {
	       if (tx!=null) tx.rollback();
	       e.printStackTrace(); 
	    } finally {
	       session.close(); 
	    }*/
		//sessionFactory.openSession().delete(associateId);
		//Associate associate = (Associate) sessionFactory.openSession().load(Associate.class,new Integer(associateId));
		//return true; 
	


	
	/*Session session = factory.openSession();
    Transaction tx = null;
    
    try {
       tx = session.beginTransaction();
       Employee employee = (Employee)session.get(Employee.class, EmployeeID); 
       session.delete(employee); 
       tx.commit();
    } catch (HibernateException e) {
       if (tx!=null) tx.rollback();
       e.printStackTrace(); 
    } finally {
       session.close(); 
    }
	*/
	
	
	
	
	
	
	
	
	
	
	
	
	
}

















/*public static HashMap<Integer, Associate>associates=new HashMap<>();

	public int insertAssociate(Associate associate) throws SQLException {

		String sql="insert into Associate(yearlyInvestmentUnder80C,firstName,lastName,department,designation,pancard,emailId) value(?,?,?,?,?,?,?)";

		int associateId= jdbcTemplate.update( sql,

				new Object[] {associate.getYearlyInvestmentUnder80C(),associate.getFirstName(),associate.getLastName(),associate.getDepartment(),associate.getDesignation(),associate.getPancard(),associate.getEmailId()}
				);

		String sql1 ="select max(associateID) from associate";
		int associateIDD=jdbcTemplate.queryForObject(sql1, Integer.class);

		String sql2="insert into Salary(associateID,basicSalary,epf,companyPf) value(?,?,?,?)";
		jdbcTemplate.update(sql2, new Object[] {associateIDD,associate.getSalary().getBasicSalary(),associate.getSalary().getEpf(),associate.getSalary().getCompanyPf()});


		String sql3="insert into BankDetails(associateID,accountNumber,bankName,ifscCode)value(?,?,?,?)";
		jdbcTemplate.update(sql3,new Object[] {associateIDD,associate.getBankdetails().getAccountNumber(),associate.getBankdetails().getBankName(),associate.getBankdetails().getIfscCode()});

		return associateId; 

	}

	@Override
	public boolean updateAssociate(Associate associate) throws SQLException {

		jdbcTemplate.update("update associate set yearlyInvestmentUnder80C=?,firstName=?,lastName=?,emailId=?,department=?,designation=?,pancard=?", associate.getYearlyInvestmentUnder80C(),associate.getFirstName(),associate.getLastName(),associate.getEmailId(),associate.getDepartment(),associate.getDesignation(),associate.getPancard());
		jdbcTemplate.update("update salary set basicSalary=?,epf=?,companyPf =? where associateId=?",associate.getAssociateID(),associate.getSalary().getBasicSalary(),associate.getSalary().getEpf(),associate.getSalary().getCompanyPf() );
		jdbcTemplate.update("update bankdetails set accountNumber=?,bankName=?,ifscCode=? where associateId=?",associate.getAssociateID(),associate.getBankdetails().getAccountNumber(),associate.getBankdetails().getBankName(),associate.getBankdetails().getIfscCode() );
		return true; 

	}

	@Override
	public boolean deleteAssociate(Associate associate) throws SQLException {


		String sql="delete from Associate where associateId=?";
		jdbcTemplate.update("associate");


		return false;
	}

	@Override
	public Associate getAssociate(int associateId) throws SQLException {
		return null;
	}

	@Override
	public List<Associate> getAssociates() throws SQLException {
		return null;
	}

	@Override
	public boolean deleteAssociate(int associateId) throws SQLException {
		return false;
	}

	@Override
	public boolean deleteAssociate1(int associateId) throws SQLException {
		return false;
	}*/









/*private Connection con=null;
	public PayrollDAOServicesImpl() throws PayrollServicesDownException {
	con = PayrollUtility.getDBConnection();	
	}


	@Override
	public int insertAssociate(Associate associate) throws SQLException  {
		try {
			con.setAutoCommit(false);
			PreparedStatement ps1=con.prepareStatement("insert into Associate(yearlyInvestmentUnder80C,firstName,lastName,department,designation,pancard,emailId) value(?,?,?,?,?,?,?)");
			ps1.setInt(1, (int) associate.getYearlyInvestmentUnder80C());
			ps1.setString(2, associate.getFirstName());
			ps1.setString(3, associate.getLastName());
			ps1.setString(4, associate.getDepartment());
			ps1.setString(5, associate.getDesignation());
			ps1.setString(6, associate.getPancard());
			ps1.setString(7, associate.getEmailId());
			ps1.executeUpdate();

			PreparedStatement ps2=con.prepareStatement("select max(associateID) from Associate");
			ResultSet rs=ps2.executeQuery();
			rs.next();
			int associateID=rs.getInt(1);

			PreparedStatement ps3=con.prepareStatement("insert into Salary(associateID,basicSalary,epf,companyPf) value(?,?,?,?)");
			ps3.setInt(1, associateID);
			ps3.setInt(2, (int) associate.getSalary().getBasicSalary());
			ps3.setLong(3, (long) associate.getSalary().getEpf());
			ps3.setFloat(4, associate.getSalary().getCompanyPf());
			ps3.executeUpdate();

			PreparedStatement ps4=con.prepareStatement("insert into BankDetails(associateID,accountNumber,bankName,ifscCode)value(?,?,?,?)");
			ps4.setInt(1, associateID);
			ps4.setInt(2, (int) associate.getBankdetails().getAccountNumber());
			ps4.setString(3, associate.getBankdetails().getBankName());
			ps4.setString(4, associate.getBankdetails().getIfscCode());
			ps4.executeUpdate();

			con.commit();
			return associateID;
		} catch (SQLException e) {
			con.rollback();
			throw e;
		}
		finally {
			con.setAutoCommit(true);
		}


	}
	@Override
	public boolean updateAssociate(Associate associate) throws SQLException {
		try {
			con.setAutoCommit(false);

			PreparedStatement ps1=con.prepareStatement("update Associate set yearlyInvestmentUnder80C=?,firstName=?,lastName=?,department=?,designation=?,pancard=?,emailId=? where associateID=?");
			ps1.setFloat(1,  associate.getYearlyInvestmentUnder80C());
			ps1.setString(2, associate.getFirstName());
			ps1.setString(3, associate.getLastName());
			ps1.setString(4, associate.getDepartment());
			ps1.setString(5, associate.getDesignation());
			ps1.setString(6, associate.getPancard());
			ps1.setString(7, associate.getEmailId());
			ps1.setInt(8, associate.getAssociateID());
			ps1.executeUpdate();

			PreparedStatement ps3=con.prepareStatement("update Salary set basicSalary=?,hra=?,conveyenceAllowance=?,otherAllowance=?,personalAllowance=?,monthlyTax=?,epf=?,companyPf=?,gratuity=?,grossSalary=?,netSalary=? where associateID=?");
			ps3.setFloat(1, associate.getSalary().getBasicSalary());
			ps3.setFloat(2, associate.getSalary().getHra());
			ps3.setFloat(3, associate.getSalary().getConveyenceAllowance());
			ps3.setFloat(4, associate.getSalary().getOtherAllowance());
			ps3.setFloat(5, associate.getSalary().getPersonalAllowance());
			ps3.setFloat(6, associate.getSalary().getMonthlyTax());
			ps3.setFloat(7, associate.getSalary().getEpf());
			ps3.setFloat(8, associate.getSalary().getCompanyPf());
			ps3.setFloat(9, associate.getSalary().getGratuity());
			ps3.setFloat(10, associate.getSalary().getGrossSalary());
			ps3.setFloat(11, associate.getSalary().getNetSalary());
			ps3.setInt(12, associate.getAssociateID());
			ps3.executeUpdate();

			PreparedStatement ps4=con.prepareStatement("update BankDetails set accountNumber=?,bankName=?,ifscCode=? where associateID=?");			
			ps4.setFloat(1, associate.getBankdetails().getAccountNumber());
			ps4.setString(2, associate.getBankdetails().getBankName());
			ps4.setString(3, associate.getBankdetails().getIfscCode());
			ps4.setInt(4, associate.getAssociateID());
			ps4.executeUpdate();

			con.commit();
			return true;
		} catch (SQLException e) {
			con.rollback();
			throw e;
		}

		finally {
			con.setAutoCommit(true);
		}




	}
	@Override
	public boolean deleteAssociate1(int associateId) throws SQLException {
		try {
		con.setAutoCommit(false);
		PreparedStatement ps1=con.prepareStatement("delete from associate where associateID=?");
		ps1.setInt(1, associateId);
		ps1.executeUpdate();
		con.commit();
		return true;

	} catch (SQLException e) {
		con.rollback();
		throw e;
	}

	finally {
		con.setAutoCommit(true);
	}

	}
	@Override
	public Associate getAssociate(int associateId) throws SQLException {

		PreparedStatement pstmt1=con.prepareStatement("SELECT   a.associateID,a.yearlyInvestmentUnder80C,a.firstName,a.lastName,a.department,a.designation,a.pancard,a.emailId,\r\n" + 
				"	b.basicSalary,b.hra,b.conveyenceAllowance,b.otherAllowance,b.personalAllowance,b.monthlyTax,b.epf,b.companyPf,b.gratuity,b.grossSalary,b.netSalary,\r\n" + 
				"	c.accountNumber,c.bankName,c.ifscCode\r\n" + 
				"FROM	associate a INNER JOIN salary b INNER JOIN  bankdetails c\r\n" + 
				"ON	a.associateID=b.associateID AND	a.associateID=c.associateID where a.associateID=?;");
		pstmt1.setInt(1, associateId);
		ResultSet rs=pstmt1.executeQuery();
		if(rs.next()) {
			return new Associate(rs.getInt("associateId"), rs.getString("firstName"), rs.getString("lastName"), rs.getString("department"), rs.getString("designation"), rs.getString("pancard"), rs.getString("emailId"),new Salary(rs.getFloat("basicSalary"), rs.getFloat("hra"), rs.getFloat("conveyenceAllowance"), rs.getFloat("otherAllowance"), rs.getFloat("personalAllowance"), rs.getFloat("monthlyTax"), rs.getFloat("epf"), rs.getFloat("companyPf"), rs.getFloat("gratuity"), rs.getFloat("grossSalary"), rs.getFloat("netSalary")), new BankDetails(rs.getInt("accountNumber"), rs.getString("bankName"), rs.getString("ifscCode")));
		}

	  return null;
 }




	@Override
	public List<Associate> getAssociates() throws SQLException {
		PreparedStatement pstmt1=con.prepareStatement("SELECT   a.associateID,a.yearlyInvestmentUnder80C,a.firstName,a.lastName,a.department,a.designation,a.pancard,a.emailId,\r\n" + 
				"	b.basicSalary,b.hra,b.conveyenceAllowance,b.otherAllowance,b.personalAllowance,b.monthlyTax,b.epf,b.companyPf,b.gratuity,b.grossSalary,b.netSalary,\r\n" + 
				"	c.accountNumber,c.bankName,c.ifscCode\r\n" + 
				"FROM	associate a INNER JOIN salary b INNER JOIN  bankdetails c\r\n" + 
				"ON	a.associateID=b.associateID AND	a.associateID=c.associateID ;");

		ResultSet rs=pstmt1.executeQuery();
		ArrayList<Associate> associate=new ArrayList<>();
		while(rs.next()) {
			associate.add(new Associate(rs.getInt("associateId"), rs.getString("firstName"), rs.getString("lastName"), rs.getString("department"), rs.getString("designation"), rs.getString("pancard"), rs.getString("emailId"),new Salary(rs.getFloat("basicSalary"), rs.getFloat("hra"), rs.getFloat("conveyenceAllowance"), rs.getFloat("otherAllowance"), rs.getFloat("personalAllowance"), rs.getFloat("monthlyTax"), rs.getFloat("epf"), rs.getFloat("companyPf"), rs.getFloat("gratuity"), rs.getFloat("grossSalary"), rs.getFloat("netSalary")), new BankDetails(rs.getInt("accountNumber"), rs.getString("bankName"), rs.getString("ifscCode"))));
		}


		return associate;


	}


	@Override
	public boolean deleteAssociate(Associate associate) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean deleteAssociate(int associateId) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}
 */
